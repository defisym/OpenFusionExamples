package _DeLib;

@FunctionalInterface
public interface Heuristic {
    int Heuristic(Coord start, Coord destination);
}
