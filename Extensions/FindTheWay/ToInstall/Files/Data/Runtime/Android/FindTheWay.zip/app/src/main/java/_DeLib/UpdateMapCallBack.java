package _DeLib;

import RunLoop.CRun;

public interface UpdateMapCallBack {
void CallBack(Object rh);
}
