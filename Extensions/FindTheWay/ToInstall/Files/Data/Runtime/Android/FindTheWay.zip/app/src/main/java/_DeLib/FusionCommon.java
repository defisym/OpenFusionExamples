package _DeLib;

public class FusionCommon {
    public static final int IDENTIFIER_ACTIVE = 1230131283;
}
