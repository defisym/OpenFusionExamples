package _DeLib;

public enum MapType {
    MAP,
    TERRAIN,
    DYNAMIC,
}
