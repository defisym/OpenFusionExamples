/* Copyright (c) 1996-2014 Clickteam
*
* This source code is part of the iOS exporter for Clickteam Multimedia Fusion 2
* and Clickteam Fusion 2.5.
* 
* Permission is hereby granted to any person obtaining a legal copy 
* of Clickteam Multimedia Fusion 2 or Clickteam Fusion 2.5 to use or modify this source 
* code for debugging, optimizing, or customizing applications created with 
* Clickteam Multimedia Fusion 2 and/or Clickteam Fusion 2.5. 
* Any other use of this source code is prohibited.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
*/
//----------------------------------------------------------------------------------
//
// CANIMDIR : Une direction d'animation
//
//----------------------------------------------------------------------------------
#import "CAnimDir.h"
#import "CFile.h"
#import "IEnum.h"

@implementation CAnimDir

-(void)dealloc
{
	free(adFrames);
	[super dealloc];
}
-(void)load:(CFile*)file 
{
	adMinSpeed=[file readAByte];
	adMaxSpeed=[file readAByte];
	adRepeat=[file readAShort];
	adRepeatFrame=[file readAShort];
	adNumberOfFrame=[file readAShort];
    
	adFrames=(short*)malloc(adNumberOfFrame*sizeof(short));
	int n;
	for (n=0; n<adNumberOfFrame; n++)
	{
		adFrames[n]=[file readAShort];
	}
}
-(void)enumElements:(id)enumImages
{
	int n;
	for (n=0; n<adNumberOfFrame; n++)
	{
	    if (enumImages!=nil)
	    {
			id<IEnum> pImages=enumImages;
			short num=[pImages enumerate:adFrames[n]];
			if (num!=-1)
			{
				adFrames[n]=num;
			}
	    }
	}
}

@end
