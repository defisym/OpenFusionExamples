# Fusion 2.5+ DX11 Shader Compile Tool

##  Custom By Defisym

you can find compiled shader in folder "**Shader_Output**"