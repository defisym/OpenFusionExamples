# Fusion 2.5+ DX11 Shader Compile Tool

##  Custom By Defisym

if use mode 1 or mode 2, you can find compiled shader in folder "**Shader_Output**"

if you drag .hlsl files onto the bat, .fxc file will be output to the **same path** of .hlsl file.

